﻿using System;
using System.Net;
using Oxide.Core;
using Oxide.Core.Libraries.Covalence;

namespace Oxide.Game.MetaTron.Libraries.Covalence
{
    /// <summary>
    /// Represents the server hosting the game instance
    /// </summary>
    public class MetaTronServer : IServer
    {
        #region Information

        /// <summary>
        /// Gets/sets the public-facing name of the server
        /// </summary>
        public string Name
        {
            get { return gEnv.pPlatform.ServerConfiguration.GameSettings.ServerName; }
            set { gEnv.pPlatform.ServerConfiguration.GameSettings.ServerName = value; }
        }

        private static IPAddress address;

        /// <summary>
        /// Gets the public-facing IP address of the server, if known
        /// </summary>
        public IPAddress Address
        {
            get
            {
                try
                {
                    if (address == null)
                    {
                        var webClient = new WebClient();
                        address = IPAddress.Parse(webClient.DownloadString("http://api.ipify.org"));
                        return address;
                    }
                    return address;
                }
                catch (Exception ex)
                {
                    RemoteLogger.Exception("Couldn't get server IP address", ex);
                    return new IPAddress(0);
                }
            }
        }

        /// <summary>
        /// Gets the public-facing network port of the server, if known
        /// </summary>
        public ushort Port => (ushort)gEnv.pPlatform.ServerConfiguration.GamePort;

        /// <summary>
        /// Gets the version or build number of the server
        /// </summary>
        public string Version => gEnv.pPlatform.CurrentVersion;

        /// <summary>
        /// Gets the network protocol version of the server
        /// </summary>
        public string Protocol => gEnv.pPlatform.CurrentVersion;

        /// <summary>
        /// Gets the total of players currently on the server
        /// </summary>
        public int Players => gEnv.pServer.AllClients.Count;

        /// <summary>
        /// Gets/sets the maximum players allowed on the server
        /// </summary>
        public int MaxPlayers
        {
            get { return gEnv.pPlatform.ServerConfiguration.MaxPlayers; }
            set { gEnv.pPlatform.ServerConfiguration.MaxPlayers = value; }
        }

        /// <summary>
        /// Gets/sets the current in-game time on the server
        /// </summary>
        public DateTime Time
        {
            get { return default(DateTime); }
            set { }
        }

        #endregion

        #region Administration

        /// <summary>
        /// Saves the server and any related information
        /// </summary>
        public void Save() => gEnv.pServer.SaveSavegame(gEnv.pPlatform.ServerConfiguration.GameSettings.SavegameNameForSaving);

        #endregion

        #region Chat and Commands

        /// <summary>
        /// Broadcasts a chat message to all users
        /// </summary>
        /// <param name="message"></param>
        public void Broadcast(string message) => gEnv.pServer.AllClients.ForEach(o=> (o as IPlayer).Message(message));

        /// <summary>
        /// Runs the specified server command
        /// </summary>
        /// <param name="command"></param>
        /// <param name="args"></param>
        public void Command(string command, params object[] args)
        {
            // TODO: Implement when possible
        }

        #endregion
    }
}
