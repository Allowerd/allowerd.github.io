﻿using System;
using Oxide.Core.Plugins;

namespace Oxide.Game.MetaTron
{
    /// <summary>
    /// Responsible for loading MetaTron core plugins
    /// </summary>
    public class MetaTronPluginLoader : PluginLoader
    {
        public override Type[] CorePlugins => new[] { typeof(MetaTronCore) };
    }
}
