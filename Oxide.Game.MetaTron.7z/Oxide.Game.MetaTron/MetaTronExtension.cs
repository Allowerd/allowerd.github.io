﻿using System;
using System.Linq;
using UnityEngine;
using Oxide.Core;
using Oxide.Core.Extensions;
using Oxide.Game.MetaTron.Libraries;

namespace Oxide.Game.MetaTron
{
    /// <summary>
    /// The extension class that represents this extension
    /// </summary>
    public class MetaTronExtension : Extension
    {
        /// <summary>
        /// Gets the name of this extension
        /// </summary>
        public override string Name => "MetaTron";

        /// <summary>
        /// Gets the version of this extension
        /// </summary>
        public override VersionNumber Version => new VersionNumber(1, 0, 0);

        /// <summary>
        /// Gets the author of this extension
        /// </summary>
        public override string Author => "Oxide Team";

        public override string[] WhitelistAssemblies => new[]
        {
            "Assembly-CSharp", "mscorlib", "Oxide.Core", "System", "System.Core", "UnityEngine"
        };
        public override string[] WhitelistNamespaces => new[]
        {
            "Steamworks", "System.Collections", "System.Security.Cryptography", "System.Text", "UnityEngine"
        };

        public static string[] Filter =
        {
            gEnv.pPlatform.CurrentVersion,
            "## The timer between the saves in the database has just STARTED",
            "CONNECTION GRANTED",
            "EAC RegisterUser: userID",
            "Ending the session of",
            "LICENCE APPROVED",
            "Periodic_Actualizer Started",
            "Player wants to connect. Waiting for approval",
            "Resulting SClient",
            "SESSION WAITING FOR AUTANTICATION",
            "Searching for a player",
            "Starting Server List Checker",
            "Token added to ConnectionTokens:",
            "UserAuthenticated:",
            "WARNING: The servers had left the Master Server list",
            "b - ServerManager - DataBase_Storing",
            "k_EBeginAuthSessionResultOK",
            "k_EUserHasLicenseResultHasLicense",
            "tmp_pos modified by raycast",
            "unloading unused assets..."
        };

        /// <summary>
        /// Initializes a new instance of the MetaTronExtension class
        /// </summary>
        /// <param name="manager"></param>
        public MetaTronExtension(ExtensionManager manager) : base(manager)
        {
        }

        /// <summary>
        /// Loads this extension
        /// </summary>
        public override void Load()
        {
            // Register our loader
            Manager.RegisterPluginLoader(new MetaTronPluginLoader());

            // Register our libraries
            Manager.RegisterLibrary("Command", new Command());
        }

        /// <summary>
        /// Loads plugin watchers used by this extension
        /// </summary>
        /// <param name="directory"></param>
        public override void LoadPluginWatchers(string directory)
        {
        }

        /// <summary>
        /// Called when all other extensions have been loaded
        /// </summary>
        public override void OnModLoad()
        {
            if (!Interface.Oxide.EnableConsole()) return;

            Application.logMessageReceived += HandleLog;

            Interface.Oxide.ServerConsole.Input += ServerConsoleOnInput;
        }

        internal static void ServerConsole()
        {
            if (Interface.Oxide.ServerConsole == null) return;

            Interface.Oxide.ServerConsole.Title = () => $"{gEnv.pServer.AllClients.Count} | {gEnv.pPlatform.ServerConfiguration.GameSettings.ServerName}";

            Interface.Oxide.ServerConsole.Status1Left = () => gEnv.pPlatform.ServerConfiguration.GameSettings.ServerName;
            Interface.Oxide.ServerConsole.Status1Right = () =>
            {
                var time = TimeSpan.FromSeconds(Time.realtimeSinceStartup);
                var uptime = $"{time.TotalHours:00}h{time.Minutes:00}m{time.Seconds:00}s".TrimStart(' ', 'd', 'h', 'm', 's', '0');
                return $"{Mathf.RoundToInt(1f / Time.smoothDeltaTime)}fps, {uptime}";
            };

            Interface.Oxide.ServerConsole.Status2Left = () => $"{gEnv.pServer.AllClients.Count}/{gEnv.pPlatform.ServerConfiguration.MaxPlayers} players";
            Interface.Oxide.ServerConsole.Status2Right = () =>
            {
                if (!gEnv.pServer.ServerIsStarted) return "not connected";
                return $"connected...";
            };

            Interface.Oxide.ServerConsole.Status3Left = () =>
            {
                return $"{gEnv.pGameTime.HHMM_EU}, " + gEnv.pPlatform.ServerConfiguration.GameSettings.SceneName;
            };
            Interface.Oxide.ServerConsole.Status3Right = () => $"Oxide {OxideMod.Version} for {gEnv.pPlatform.CurrentVersion}";
            Interface.Oxide.ServerConsole.Status3RightColor = ConsoleColor.Yellow;
        }

        private void ServerConsoleOnInput(string input)
        {
            if (!string.IsNullOrEmpty(input)) Interface.Call("OnServerCommand", input);
        }

        private static void HandleLog(string message, string stackTrace, LogType type)
        {
            if (string.IsNullOrEmpty(message) || Filter.Any(message.StartsWith)) return;

            var color = ConsoleColor.Gray;
            if (type == LogType.Warning)
                color = ConsoleColor.Yellow;
            else if (type == LogType.Error || type == LogType.Exception || type == LogType.Assert)
                color = ConsoleColor.Red;
            Interface.Oxide.ServerConsole.AddMessage(message, color);
        }
    }
}
